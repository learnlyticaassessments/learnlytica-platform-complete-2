# Expense Claim Submission Portal (Phase 1 Demo)

React + Vite sample project for Learnlytica Project Evaluations Phase 1.

Flow covered:
- submit expense claim form
- validation
- success message
- recent claims table updates
