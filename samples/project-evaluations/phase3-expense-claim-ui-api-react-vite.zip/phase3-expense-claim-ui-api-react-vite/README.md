# Expense Claim Submission Portal (Phase 3 Sample)

React + Vite sample project for Learnlytica Phase 3 (UI + API Integration).

Flow covered:
- submit expense claim form
- validation
- success message
- recent claims table updates
- API checks:
  - `GET /api/health`
  - `POST /api/claims`
  - `GET /api/claims`
