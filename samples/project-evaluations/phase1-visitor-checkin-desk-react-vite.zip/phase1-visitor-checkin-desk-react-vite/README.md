# Visitor Check-In Desk (Phase 1 Demo)

React + Vite sample project for Learnlytica Project Evaluations Phase 1.

Flow covered:
- visitor check-in form
- required validation
- success message
- today's visitors table updates
