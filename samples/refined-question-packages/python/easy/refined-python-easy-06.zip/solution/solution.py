def evaluateCase(payload):
    amount = float(payload.get("amount", 0))
    required = payload.get("requiredComplete", True)
    duplicate = payload.get("duplicate", False)
    risk = payload.get("riskScore", 0)

    if not required:
      return {"approved": False, "reason": "MISSING_REQUIRED_FIELDS", "riskLevel": "high"}
    if duplicate:
      return {"approved": False, "reason": "DUPLICATE_SUBMISSION", "riskLevel": "high"}
    if amount > 1000:
      return {"approved": False, "reason": "POLICY_LIMIT_EXCEEDED", "riskLevel": "medium"}
    if risk >= 80:
      return {"approved": False, "reason": "MANUAL_REVIEW_REQUIRED", "riskLevel": "high"}

    return {"approved": True, "reason": "APPROVED", "riskLevel": "low"}
