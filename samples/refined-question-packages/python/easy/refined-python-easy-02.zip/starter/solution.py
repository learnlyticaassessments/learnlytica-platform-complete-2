def evaluateCase(payload):
    # TODO: implement business logic
    return {"approved": False, "reason": "NOT_IMPLEMENTED", "riskLevel": "unknown"}
