function evaluateCase(payload) {
  const amount = Number(payload?.amount ?? 0);
  const required = Boolean(payload?.requiredComplete ?? true);
  const duplicate = Boolean(payload?.duplicate ?? false);
  const risk = Number(payload?.riskScore ?? 0);

  if (!required) return { approved: false, reason: 'MISSING_REQUIRED_FIELDS', riskLevel: 'high' };
  if (duplicate) return { approved: false, reason: 'DUPLICATE_SUBMISSION', riskLevel: 'high' };
  if (amount > 1000) return { approved: false, reason: 'POLICY_LIMIT_EXCEEDED', riskLevel: 'medium' };
  if (risk >= 80) return { approved: false, reason: 'MANUAL_REVIEW_REQUIRED', riskLevel: 'high' };
  return { approved: true, reason: 'APPROVED', riskLevel: 'low' };
}

module.exports = { evaluateCase };
