import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<main><h1>Returns Processing Queue</h1><p>TODO: Implement form and list flow</p></main>`
})
export class AppComponent {}
