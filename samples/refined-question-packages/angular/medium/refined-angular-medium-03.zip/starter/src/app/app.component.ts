import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<main><h1>Visitor Check-In Desk</h1><p>TODO: Implement form and list flow</p></main>`
})
export class AppComponent {}
