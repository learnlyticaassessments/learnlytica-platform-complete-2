import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<main><h1>Support Ticket Intake Portal</h1><p>TODO: Implement form and list flow</p></main>`
})
export class AppComponent {}
