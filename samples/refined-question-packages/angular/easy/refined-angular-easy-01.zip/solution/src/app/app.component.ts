import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <main>
      <h1>Expense Claim Submission Portal</h1>
      <form aria-label="submission form">
        <label>Name <input aria-label="Name" /></label>
        <label>Email <input aria-label="Email" /></label>
        <button type="submit">Create</button>
      </form>
      <section><h2>Recent claims</h2></section>
    </main>
  `
})
export class AppComponent {}
