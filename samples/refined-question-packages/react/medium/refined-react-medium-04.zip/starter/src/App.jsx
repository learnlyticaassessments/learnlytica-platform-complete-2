export default function App() {
  return (
    <main>
      <h1>Invoice Review Console</h1>
      <p>TODO: Implement form and list flow</p>
    </main>
  );
}
