export default function App() {
  return (
    <main>
      <h1>Visitor Check-In Desk</h1>
      <p>TODO: Implement form and list flow</p>
    </main>
  );
}
