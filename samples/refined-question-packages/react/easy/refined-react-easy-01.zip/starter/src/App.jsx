export default function App() {
  return (
    <main>
      <h1>Expense Claim Submission Portal</h1>
      <p>TODO: Implement form and list flow</p>
    </main>
  );
}
