export default function App() {
  return (
    <main>
      <h1>Support Ticket Intake Portal</h1>
      <form aria-label="submission form">
        <label htmlFor="name">Name</label>
        <input id="name" aria-label="Name" />
        <label htmlFor="email">Email</label>
        <input id="email" aria-label="Email" />
        <button type="submit">Create</button>
      </form>
      <section><h2>Recent tickets</h2></section>
    </main>
  );
}
