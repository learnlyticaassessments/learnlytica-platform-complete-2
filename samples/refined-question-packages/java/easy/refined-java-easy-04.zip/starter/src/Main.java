import java.util.Map;
import java.util.HashMap;

public class Evaluator {
  public static Map<String, Object> evaluateCase(Map<String, Object> payload) {
    Map<String, Object> out = new HashMap<>();
    out.put("approved", false);
    out.put("reason", "NOT_IMPLEMENTED");
    out.put("riskLevel", "unknown");
    return out;
  }
}
