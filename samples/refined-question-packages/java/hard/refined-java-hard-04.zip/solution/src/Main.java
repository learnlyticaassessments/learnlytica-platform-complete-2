import java.util.Map;
import java.util.HashMap;

public class Evaluator {
  public static Map<String, Object> evaluateCase(Map<String, Object> payload) {
    Map<String, Object> out = new HashMap<>();
    double amount = ((Number) payload.getOrDefault("amount", 0)).doubleValue();
    boolean required = (boolean) payload.getOrDefault("requiredComplete", true);
    boolean duplicate = (boolean) payload.getOrDefault("duplicate", false);
    int risk = ((Number) payload.getOrDefault("riskScore", 0)).intValue();

    if (!required) { out.put("approved", false); out.put("reason", "MISSING_REQUIRED_FIELDS"); out.put("riskLevel", "high"); return out; }
    if (duplicate) { out.put("approved", false); out.put("reason", "DUPLICATE_SUBMISSION"); out.put("riskLevel", "high"); return out; }
    if (amount > 2000) { out.put("approved", false); out.put("reason", "POLICY_LIMIT_EXCEEDED"); out.put("riskLevel", "medium"); return out; }
    if (risk >= 80) { out.put("approved", false); out.put("reason", "MANUAL_REVIEW_REQUIRED"); out.put("riskLevel", "high"); return out; }

    out.put("approved", true); out.put("reason", "APPROVED"); out.put("riskLevel", "low"); return out;
  }
}
